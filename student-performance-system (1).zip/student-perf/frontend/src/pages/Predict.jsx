import { useState } from 'react';
import { predict } from '../services/api';
import ResultCard from '../components/ResultCard';
import '../styles/Predict.css';

const initialForm = { attendance: '', studyHours: '', internalMarks: '', assignments: '' };

function validate(form) {
  const errors = {};
  const att = parseFloat(form.attendance);
  const sh = parseFloat(form.studyHours);
  const im = parseFloat(form.internalMarks);
  if (form.attendance === '' || isNaN(att) || att < 0 || att > 100)
    errors.attendance = 'Enter a value between 0 and 100';
  if (form.studyHours === '' || isNaN(sh) || sh < 0 || sh > 24)
    errors.studyHours = 'Enter a value between 0 and 24';
  if (form.internalMarks === '' || isNaN(im) || im < 0 || im > 50)
    errors.internalMarks = 'Enter a value between 0 and 50';
  if (form.assignments === '') errors.assignments = 'Please select an option';
  return errors;
}

export default function Predict() {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [apiError, setApiError] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: '' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate(form);
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    setApiError('');
    try {
      const res = await predict({
        attendance: parseFloat(form.attendance),
        studyHours: parseFloat(form.studyHours),
        internalMarks: parseFloat(form.internalMarks),
        assignments: parseInt(form.assignments),
      });
      setResult(res.data);
    } catch (err) {
      setApiError(err.response?.data?.error || 'Could not connect to backend. Is Flask running?');
    } finally {
      setLoading(false);
    }
  };

  if (result) return <ResultCard result={result} onReset={() => { setResult(null); setForm(initialForm); }} />;

  return (
    <div className="predict-page">
      <div className="predict-header">
        <h1>Predict Performance</h1>
        <p>Fill in the student details below to get an ML-powered prediction.</p>
      </div>

      {apiError && <div className="api-error">⚠️ {apiError}</div>}

      <form className="predict-form" onSubmit={handleSubmit} noValidate>
        <div className="form-group">
          <label>Attendance Percentage <span className="hint">(0 – 100)</span></label>
          <input
            type="number" name="attendance" value={form.attendance}
            onChange={handleChange} placeholder="e.g. 85" min="0" max="100" step="0.1"
            className={errors.attendance ? 'input-error' : ''}
          />
          {errors.attendance && <span className="error-msg">{errors.attendance}</span>}
        </div>

        <div className="form-group">
          <label>Study Hours per Day <span className="hint">(0 – 24)</span></label>
          <input
            type="number" name="studyHours" value={form.studyHours}
            onChange={handleChange} placeholder="e.g. 4" min="0" max="24" step="0.5"
            className={errors.studyHours ? 'input-error' : ''}
          />
          {errors.studyHours && <span className="error-msg">{errors.studyHours}</span>}
        </div>

        <div className="form-group">
          <label>Internal Marks <span className="hint">(0 – 50)</span></label>
          <input
            type="number" name="internalMarks" value={form.internalMarks}
            onChange={handleChange} placeholder="e.g. 38" min="0" max="50" step="0.5"
            className={errors.internalMarks ? 'input-error' : ''}
          />
          {errors.internalMarks && <span className="error-msg">{errors.internalMarks}</span>}
        </div>

        <div className="form-group">
          <label>Assignments Completed</label>
          <div className="radio-group">
            <label className={`radio-btn ${form.assignments === '1' ? 'selected' : ''}`}>
              <input type="radio" name="assignments" value="1" onChange={handleChange} />
              ✅ Yes
            </label>
            <label className={`radio-btn ${form.assignments === '0' ? 'selected' : ''}`}>
              <input type="radio" name="assignments" value="0" onChange={handleChange} />
              ❌ No
            </label>
          </div>
          {errors.assignments && <span className="error-msg">{errors.assignments}</span>}
        </div>

        <button type="submit" className="btn-submit" disabled={loading}>
          {loading ? <span className="loader" /> : 'Predict Score →'}
        </button>
      </form>
    </div>
  );
}
