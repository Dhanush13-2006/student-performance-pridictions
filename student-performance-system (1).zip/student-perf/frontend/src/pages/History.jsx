import { useEffect, useState } from 'react';
import { getHistory } from '../services/api';
import '../styles/History.css';

const levelColor = {
  Distinction: '#10b981', 'First Class': '#3b82f6',
  'Second Class': '#f59e0b', Pass: '#8b5cf6', Fail: '#ef4444',
};

export default function History() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getHistory()
      .then((r) => setRows(r.data))
      .catch(() => setError('Could not load history. Is the backend running?'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="history-loading"><div className="spinner" />Loading history…</div>;
  if (error) return <div className="history-error">⚠️ {error}</div>;

  return (
    <div className="history-page">
      <div className="history-header">
        <h1>Prediction History</h1>
        <p>Last 50 predictions stored in the database.</p>
      </div>

      {rows.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📭</div>
          <p>No predictions yet. <a href="/predict">Make your first one →</a></p>
        </div>
      ) : (
        <div className="table-wrapper">
          <table className="history-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Attendance</th>
                <th>Study Hrs</th>
                <th>Internal</th>
                <th>Assignments</th>
                <th>Score</th>
                <th>Status</th>
                <th>Level</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.id}>
                  <td className="row-num">{i + 1}</td>
                  <td>{r.attendance}%</td>
                  <td>{r.study_hours}h</td>
                  <td>{r.internal_marks}</td>
                  <td>{r.assignments ? '✅ Yes' : '❌ No'}</td>
                  <td><strong>{r.predicted_score}</strong></td>
                  <td>
                    <span className={`pill ${r.pass_fail === 'Pass' ? 'pill-pass' : 'pill-fail'}`}>
                      {r.pass_fail}
                    </span>
                  </td>
                  <td>
                    <span className="pill-level" style={{ color: levelColor[r.performance_level], background: levelColor[r.performance_level] + '18' }}>
                      {r.performance_level}
                    </span>
                  </td>
                  <td className="date-cell">{r.created_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
