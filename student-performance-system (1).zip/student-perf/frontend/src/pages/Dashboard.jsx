import { useEffect, useState } from 'react';
import { getStats, getHistory } from '../services/api';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line, CartesianGrid,
} from 'recharts';
import '../styles/Dashboard.css';

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#ef4444'];

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([getStats(), getHistory()])
      .then(([s, h]) => { setStats(s.data); setHistory(h.data.slice().reverse()); })
      .catch(() => setError('Could not load dashboard data. Is the backend running?'));
  }, []);

  if (error) return <div className="dash-error">⚠️ {error}</div>;
  if (!stats) return <div className="dash-loading"><div className="spinner" />Loading dashboard…</div>;

  const pieData = Object.entries(stats.levels || {}).map(([name, value]) => ({ name, value }));
  const lineData = history.slice(-20).map((r, i) => ({ index: i + 1, score: r.predicted_score }));
  const barData = Object.entries(stats.levels || {}).map(([name, value]) => ({ name, count: value }));

  return (
    <div className="dashboard">
      <div className="dash-header">
        <h1>Analytics Dashboard</h1>
        <p>Summary of all predictions made so far.</p>
      </div>

      <div className="stat-cards">
        <div className="stat-card">
          <span className="stat-icon">📋</span>
          <div><p>Total Predictions</p><h2>{stats.total}</h2></div>
        </div>
        <div className="stat-card">
          <span className="stat-icon">✅</span>
          <div><p>Pass Rate</p><h2>{stats.passRate}%</h2></div>
        </div>
        <div className="stat-card">
          <span className="stat-icon">📈</span>
          <div><p>Average Score</p><h2>{stats.avgScore}</h2></div>
        </div>
      </div>

      {stats.total === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📊</div>
          <p>No data yet. <a href="/predict">Make some predictions first →</a></p>
        </div>
      ) : (
        <div className="charts-grid">
          <div className="chart-card">
            <h3>Performance Distribution</h3>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card">
            <h3>Grade Count (Bar)</h3>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={barData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {barData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card chart-wide">
            <h3>Score Trend (Last 20 Predictions)</h3>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={lineData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="index" label={{ value: 'Prediction #', position: 'insideBottom', offset: -2, fontSize: 12 }} />
                <YAxis domain={[0, 100]} />
                <Tooltip formatter={(v) => v.toFixed(1)} />
                <Line type="monotone" dataKey="score" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
