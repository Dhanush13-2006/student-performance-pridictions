import { useNavigate } from 'react-router-dom';
import '../styles/Home.css';

const features = [
  { icon: '🤖', title: 'ML-Powered', desc: 'Random Forest model trained on real academic patterns' },
  { icon: '📊', title: 'Detailed Analytics', desc: 'Charts & history dashboard to track predictions' },
  { icon: '⚡', title: 'Instant Results', desc: 'Get score, pass/fail status, and grade in seconds' },
  { icon: '🌙', title: 'Dark Mode', desc: 'Easy on the eyes — toggle anytime from the nav' },
];

export default function Home() {
  const navigate = useNavigate();
  return (
    <div className="home">
      <section className="hero">
        <div className="hero-badge">Final Year Project · ML Web App</div>
        <h1>Student Performance<br /><span className="gradient-text">Prediction System</span></h1>
        <p className="hero-sub">
          Enter study metrics and let our machine learning model predict your final exam score,
          pass/fail status, and academic performance level.
        </p>
        <div className="hero-btns">
          <button className="btn-primary" onClick={() => navigate('/predict')}>Start Predicting →</button>
          <button className="btn-secondary" onClick={() => navigate('/dashboard')}>View Dashboard</button>
        </div>
      </section>

      <section className="features">
        {features.map((f) => (
          <div className="feature-card" key={f.title}>
            <div className="feature-icon">{f.icon}</div>
            <h3>{f.title}</h3>
            <p>{f.desc}</p>
          </div>
        ))}
      </section>

      <section className="how-it-works">
        <h2>How It Works</h2>
        <div className="steps">
          {[
            { n: '01', t: 'Enter Data', d: 'Fill in attendance, study hours, internal marks, and assignments.' },
            { n: '02', t: 'ML Prediction', d: 'Our Random Forest model processes the inputs in real time.' },
            { n: '03', t: 'See Results', d: 'Get a predicted score, pass/fail status, and performance grade.' },
          ].map((s) => (
            <div className="step" key={s.n}>
              <div className="step-num">{s.n}</div>
              <h4>{s.t}</h4>
              <p>{s.d}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
