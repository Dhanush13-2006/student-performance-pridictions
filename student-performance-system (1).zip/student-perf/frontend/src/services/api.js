import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:5000' });

export const predict = (data) => API.post('/predict', data);
export const getHistory = () => API.get('/history');
export const getStats = () => API.get('/stats');
export const healthCheck = () => API.get('/health');
