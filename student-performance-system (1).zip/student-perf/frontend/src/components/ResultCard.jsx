import '../styles/ResultCard.css';

const levelColors = {
  Distinction: '#10b981',
  'First Class': '#3b82f6',
  'Second Class': '#f59e0b',
  Pass: '#8b5cf6',
  Fail: '#ef4444',
};

const levelEmoji = {
  Distinction: '🏆',
  'First Class': '🥇',
  'Second Class': '🥈',
  Pass: '✅',
  Fail: '❌',
};

export default function ResultCard({ result, onReset }) {
  const { predictedScore, passFail, performanceLevel } = result;
  const color = levelColors[performanceLevel] || '#6b7280';
  const emoji = levelEmoji[performanceLevel] || '📊';
  const pct = Math.round(predictedScore);
  const circumference = 2 * Math.PI * 54;
  const offset = circumference - (pct / 100) * circumference;

  return (
    <div className="result-card">
      <div className="result-header">
        <span className="result-emoji">{emoji}</span>
        <h2>Prediction Result</h2>
      </div>

      <div className="score-ring-wrapper">
        <svg width="140" height="140" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="54" fill="none" stroke="var(--ring-bg)" strokeWidth="10" />
          <circle
            cx="60" cy="60" r="54" fill="none"
            stroke={color} strokeWidth="10"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            transform="rotate(-90 60 60)"
            style={{ transition: 'stroke-dashoffset 1s ease' }}
          />
          <text x="60" y="56" textAnchor="middle" fontSize="22" fontWeight="700" fill={color}>{pct}</text>
          <text x="60" y="72" textAnchor="middle" fontSize="11" fill="var(--text-secondary)">/ 100</text>
        </svg>
      </div>

      <div className="result-badges">
        <span className={`badge ${passFail === 'Pass' ? 'badge-pass' : 'badge-fail'}`}>
          {passFail === 'Pass' ? '✓ Pass' : '✗ Fail'}
        </span>
        <span className="badge badge-level" style={{ background: color + '22', color }}>
          {performanceLevel}
        </span>
      </div>

      <div className="result-breakdown">
        <div className="breakdown-item">
          <span>Score</span>
          <strong>{predictedScore.toFixed(1)}</strong>
        </div>
        <div className="breakdown-item">
          <span>Status</span>
          <strong style={{ color: passFail === 'Pass' ? '#10b981' : '#ef4444' }}>{passFail}</strong>
        </div>
        <div className="breakdown-item">
          <span>Grade</span>
          <strong style={{ color }}>{performanceLevel}</strong>
        </div>
      </div>

      <button className="btn-reset" onClick={onReset}>← Predict Again</button>
    </div>
  );
}
