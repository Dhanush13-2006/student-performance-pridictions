from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import numpy as np
import sqlite3
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

DB_PATH = 'predictions.db'
MODEL_PATH = 'model.pkl'

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            attendance REAL NOT NULL,
            study_hours REAL NOT NULL,
            internal_marks REAL NOT NULL,
            assignments INTEGER NOT NULL,
            predicted_score REAL NOT NULL,
            pass_fail TEXT NOT NULL,
            performance_level TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def load_model():
    if not os.path.exists(MODEL_PATH):
        return None
    with open(MODEL_PATH, 'rb') as f:
        return pickle.load(f)

def get_performance_level(score):
    if score >= 85:
        return 'Distinction'
    elif score >= 70:
        return 'First Class'
    elif score >= 55:
        return 'Second Class'
    elif score >= 40:
        return 'Pass'
    else:
        return 'Fail'

init_db()
model = load_model()

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'model_loaded': model is not None})

@app.route('/predict', methods=['POST'])
def predict():
    global model
    if model is None:
        model = load_model()
    if model is None:
        return jsonify({'error': 'Model not found. Run train_model.py first.'}), 503

    data = request.get_json()
    if not data:
        return jsonify({'error': 'No JSON body provided'}), 400

    required = ['attendance', 'studyHours', 'internalMarks', 'assignments']
    for field in required:
        if field not in data:
            return jsonify({'error': f'Missing field: {field}'}), 400

    try:
        attendance = float(data['attendance'])
        study_hours = float(data['studyHours'])
        internal_marks = float(data['internalMarks'])
        assignments = int(data['assignments'])
    except (ValueError, TypeError) as e:
        return jsonify({'error': f'Invalid input: {e}'}), 400

    if not (0 <= attendance <= 100):
        return jsonify({'error': 'Attendance must be between 0 and 100'}), 400
    if not (0 <= study_hours <= 24):
        return jsonify({'error': 'Study hours must be between 0 and 24'}), 400
    if not (0 <= internal_marks <= 50):
        return jsonify({'error': 'Internal marks must be between 0 and 50'}), 400
    if assignments not in (0, 1):
        return jsonify({'error': 'Assignments must be 0 or 1'}), 400

    features = np.array([[attendance, study_hours, internal_marks, assignments]])
    predicted_score = float(np.clip(model.predict(features)[0], 0, 100))
    pass_fail = 'Pass' if predicted_score >= 40 else 'Fail'
    performance_level = get_performance_level(predicted_score)

    conn = get_db()
    conn.execute('''
        INSERT INTO predictions (attendance, study_hours, internal_marks, assignments,
            predicted_score, pass_fail, performance_level, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (attendance, study_hours, internal_marks, assignments,
          round(predicted_score, 2), pass_fail, performance_level,
          datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    conn.commit()
    conn.close()

    return jsonify({
        'predictedScore': round(predicted_score, 2),
        'passFail': pass_fail,
        'performanceLevel': performance_level
    })

@app.route('/history', methods=['GET'])
def history():
    conn = get_db()
    rows = conn.execute(
        'SELECT * FROM predictions ORDER BY created_at DESC LIMIT 50'
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route('/stats', methods=['GET'])
def stats():
    conn = get_db()
    rows = conn.execute('SELECT predicted_score, pass_fail, performance_level FROM predictions').fetchall()
    conn.close()
    if not rows:
        return jsonify({'total': 0, 'passRate': 0, 'avgScore': 0, 'levels': {}})
    scores = [r['predicted_score'] for r in rows]
    passes = sum(1 for r in rows if r['pass_fail'] == 'Pass')
    levels = {}
    for r in rows:
        levels[r['performance_level']] = levels.get(r['performance_level'], 0) + 1
    return jsonify({
        'total': len(rows),
        'passRate': round(passes / len(rows) * 100, 1),
        'avgScore': round(sum(scores) / len(scores), 2),
        'levels': levels
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
