import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import pickle
import os

np.random.seed(42)
n = 1000

attendance = np.random.uniform(40, 100, n)
study_hours = np.random.uniform(0, 12, n)
internal_marks = np.random.uniform(20, 50, n)
assignments = np.random.randint(0, 2, n)

final_score = (
    0.30 * attendance
    + 2.5 * study_hours
    + 0.80 * internal_marks
    + 5.0 * assignments
    + np.random.normal(0, 3, n)
)
final_score = np.clip(final_score, 0, 100)

df = pd.DataFrame({
    'Attendance': attendance,
    'StudyHours': study_hours,
    'InternalMarks': internal_marks,
    'Assignments': assignments,
    'FinalScore': final_score
})

df.to_csv('dataset.csv', index=False)
print("Dataset saved to dataset.csv")

X = df[['Attendance', 'StudyHours', 'InternalMarks', 'Assignments']]
y = df['FinalScore']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestRegressor(n_estimators=100, random_state=42, max_depth=10)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)
print(f"RMSE: {rmse:.2f}")
print(f"R2 Score: {r2:.4f}")

with open('model.pkl', 'wb') as f:
    pickle.dump(model, f)
print("Model saved to model.pkl")
