# EduPredict — Student Performance Prediction System

A full-stack ML web application built with React.js, Flask, Scikit-learn, and SQLite.

---

## Project Structure

```
student-perf/
├── backend/
│   ├── app.py              # Flask REST API
│   ├── train_model.py      # ML model training script
│   ├── requirements.txt    # Python dependencies
│   ├── model.pkl           # Trained model (generated after training)
│   ├── dataset.csv         # Synthetic dataset (generated after training)
│   └── predictions.db      # SQLite database (auto-created)
└── frontend/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── App.js
    │   ├── index.js
    │   ├── components/
    │   │   ├── Navbar.jsx
    │   │   └── ResultCard.jsx
    │   ├── pages/
    │   │   ├── Home.jsx
    │   │   ├── Predict.jsx
    │   │   ├── History.jsx
    │   │   └── Dashboard.jsx
    │   ├── services/
    │   │   └── api.js
    │   └── styles/
    │       ├── global.css
    │       ├── Navbar.css
    │       ├── Home.css
    │       ├── Predict.css
    │       ├── ResultCard.css
    │       ├── History.css
    │       └── Dashboard.css
    └── package.json
```

---

## Setup Instructions

### Prerequisites
- Python 3.9+
- Node.js 18+
- npm or yarn

---

### Step 1 — Train the ML Model

```bash
cd backend
pip install -r requirements.txt
python train_model.py
```

This generates `model.pkl` and `dataset.csv`.

---

### Step 2 — Start the Flask Backend

```bash
cd backend
python app.py
```

The API runs at `http://localhost:5000`.

**Endpoints:**
| Method | Path | Description |
|--------|------|-------------|
| GET | /health | Check server status |
| POST | /predict | Get prediction |
| GET | /history | Fetch past predictions |
| GET | /stats | Aggregate statistics |

**POST /predict body (JSON):**
```json
{
  "attendance": 85.5,
  "studyHours": 4,
  "internalMarks": 38,
  "assignments": 1
}
```

---

### Step 3 — Start the React Frontend

```bash
cd frontend
npm install
npm start
```

The app opens at `http://localhost:3000`.

---

## Features

- **Home page** — Landing page with feature overview and how-it-works section
- **Predict page** — Form with validation, loading animation, result card with animated score ring
- **History page** — Table of all past predictions from SQLite
- **Dashboard page** — Pie chart, bar chart, and line chart (Recharts) with summary stats
- **Dark mode** — Toggle from the navbar, persists for the session
- **Mobile responsive** — Hamburger nav, responsive grids

---

## ML Model Details

- **Algorithm:** RandomForestRegressor (100 trees, max_depth=10)
- **Features:** Attendance, StudyHours, InternalMarks, Assignments
- **Target:** FinalScore (0–100)
- **Training data:** 1000 synthetically generated samples
- **Performance grading:**
  - ≥ 85 → Distinction
  - ≥ 70 → First Class
  - ≥ 55 → Second Class
  - ≥ 40 → Pass
  - < 40 → Fail

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, React Router 6, Recharts, Axios |
| Backend | Python Flask, Flask-CORS |
| ML | Scikit-learn RandomForestRegressor |
| Database | SQLite (via sqlite3) |
| Styling | Custom CSS with CSS variables (dark mode) |
